﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlashLightController : MonoBehaviour
{
    #region Fields
    [SerializeField] Light _flashLight;
    [SerializeField] float _intensity = 1.0f;
    
    #endregion


    #region UnityMethods    

    private void Start()
    {

    }

    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.F))
        {
            if (_flashLight.intensity != _intensity)
            {
                _flashLight.intensity = _intensity;
                print("flashLight ON");
            }
            else
            {
                _flashLight.intensity = 0.0f;
                print("flashLight OFF");
            }
        }
    }

    #endregion


    #region Methods 
    #endregion

}

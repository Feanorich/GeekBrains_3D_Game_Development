﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunController : MonoBehaviour
{
    #region Fields
    [SerializeField] private Camera _mainCamera;
    [SerializeField] private GameObject _point;
    [SerializeField] private Transform _dir;
    [SerializeField] private GameObject _impactEffect;
    [SerializeField] private GameObject _flashEffect;
    [SerializeField] private float _flashTime = 0.1f;
    #endregion


    #region UnityMethods    

    private void Start()
    {

    }

    private void Update()
    {
        if (Physics.Raycast(_mainCamera.ScreenPointToRay(Input.mousePosition), out var hit))
        {
            if (Input.GetMouseButtonDown(0))
            {
                DrawPoint(hit.point);
            }            
        }
    }

    #endregion


    #region Methods 

    private void DrawPoint(Vector3 position)
    {
        //var point = Instantiate(_point, position, Quaternion.identity);

        //var point = Instantiate(_point, position, _dir.rotation);
        var impact = Instantiate(_impactEffect, position, _dir.rotation);
        Destroy(impact, 1);

        var flash = Instantiate(_flashEffect, position, _dir.rotation);
        Destroy(flash, _flashTime);

    }

    #endregion
}

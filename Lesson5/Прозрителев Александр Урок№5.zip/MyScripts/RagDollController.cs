﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RagDollController : MonoBehaviour
{
    #region Fields
    [SerializeField] private Rigidbody _rigidbodyToPush;
    [SerializeField] private float _killForce = 5.0f;
    [SerializeField] private bool _kill;
    [SerializeField] private bool _revive;

    private Rigidbody[] _rigidbodyes;
    private Collider[] _colliders;
    private Animator _animator;
    #endregion


    #region UnityMethods    

    private void Start()
    {
        _animator = GetComponent<Animator>();
        _rigidbodyes = GetComponentsInChildren<Rigidbody>();
        _colliders = GetComponentsInChildren<Collider>();

        Revive();
    }

    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.K))
        {
            _kill = true;
        }

        if (Input.GetKeyUp(KeyCode.R))
        {
            _revive = true;
        }

        if (_kill == true)
        {
            Kill();
        }
        if (_revive == true)
        {
            Revive();
        }
    }

    #endregion


    #region Methods 

    private void Kill()
    {
        _kill = false;

        SetRagdollState(true);
        SetMainPhysics(false);

        var body = _rigidbodyToPush;
        var force = body.transform.up;

        force = force * _killForce * body.mass;
        body.AddForce(force, ForceMode.Impulse);
    }

    private void Revive()
    {
        _revive = false;

        SetRagdollState(false);
        SetMainPhysics(true);
    }

    private void SetRagdollState(bool activityState)
    {
        for (int i = 1; i < _rigidbodyes.Length; i++)
        {
            _rigidbodyes[i].isKinematic = !activityState;
            _colliders[i].enabled = activityState;
        }
    }

    private void SetMainPhysics(bool activityState)
    {
        _animator.enabled = activityState;
        _rigidbodyes[0].isKinematic = !activityState;
        _colliders[0].enabled = activityState;
    }

    #endregion
}

﻿using UnityEngine;
using System;
using System.Collections;

[RequireComponent(typeof(Animator))]

public class IKControl : MonoBehaviour
{
    #region Fields
    
    protected Animator animator;

    public bool ikActive = false;
    public Transform rightHandObj = null;
    public Transform leftHandObj = null;
    public Transform lookObj = null;

    #endregion


    #region UnityMethods  

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    //Вызывается при расчёте IK
    void OnAnimatorIK()
    {
        if (animator)
        {

            //Если, мы включили IK, устанавливаем позицию и вращение
            if (ikActive)
            {

                // Устанавливаем цель взгляда для головы
                if (lookObj != null)
                {
                    animator.SetLookAtWeight(1);
                    animator.SetLookAtPosition(lookObj.position);
                }

                //// Устанавливаем цель для рук и выставляем их в позицию              

                SetTarget(rightHandObj, AvatarIKGoal.RightHand);
                SetTarget(leftHandObj, AvatarIKGoal.LeftHand);
            }

            // Если IK неактивен, ставим позицию и вращение рук и головы в изначальное положение
            else
            {
                SetIKWeight(AvatarIKGoal.RightHand, 0);
                SetIKWeight(AvatarIKGoal.LeftHand, 0);
                animator.SetLookAtWeight(0);
            }
        }
    }

    #endregion


    #region Methods 

    private void SetIKWeight(AvatarIKGoal hand, float weight)
    {
        animator.SetIKPositionWeight(hand, weight);
        animator.SetIKRotationWeight(hand, weight);
    }

    private void SetTarget(Transform targetObj, AvatarIKGoal hand)
    {
        if (targetObj != null)
        {
            SetIKWeight(hand, 1);            
            animator.SetIKPosition(hand, targetObj.position);
            animator.SetIKRotation(hand, targetObj.rotation);
        }
    }

    #endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistolController : MonoBehaviour
{
    #region Fields

    [SerializeField] private IKControl _IKControl;
    [SerializeField] private Transform _pistols;
    [SerializeField] private Transform _righthand;
    [SerializeField] private Transform _lefthand;

    [SerializeField] private Transform _upPistol;
    [SerializeField] private Transform _downPistol;
    [SerializeField] private float _attakSpeed = 50.0f;

    public bool _armed = false;
    private bool _rotate = false;
    private float rotation;

    #endregion


    #region UnityMethods    

    private void Start()
    {

    }

    private void Update()
    {
        if (Input.GetKeyUp(KeyCode.P))
        {
            _rotate = true;
            if (_armed)
            {
                _rotate = true;
            }
            else
            {                
                _IKControl.rightHandObj = _righthand;
                _IKControl.leftHandObj = _lefthand;
                _IKControl.ikActive = true;

                _rotate = true;
            }
        }

        if (_rotate)
        {
            if (_armed)
            {                
                RotateWearpon(_downPistol.rotation, false);
            }
            else
            {                
                RotateWearpon(_upPistol.rotation, true);
            }
            
        }
    }

    #endregion


    #region Methods 

    private void RotateWearpon(Quaternion attakDirection, bool armed)
    {
        //_pistols.rotation = attakDirection;
        //_armed = armed;

        rotation = _attakSpeed * Time.deltaTime;

        _pistols.rotation = Quaternion.RotateTowards(_pistols.rotation, attakDirection, rotation);

        if (_pistols.rotation == attakDirection)
        {
            _pistols.rotation = attakDirection;
            _armed = armed;
            _rotate = false;

            if (!_armed)
            {
                _IKControl.rightHandObj = null;
                _IKControl.leftHandObj = null;
                _IKControl.ikActive = false;
            }
        }
    }

    #endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HandRay : MonoBehaviour
{
    #region Fields
    [SerializeField] private PistolController _pistolController;
    [SerializeField] private IKControl _IKControl;
    [SerializeField] private AvatarIKGoal _hand;
    [SerializeField] Transform _handPos;
    [SerializeField] private LayerMask rayLayer;
    [SerializeField] private float _range = 2.0f;
    [SerializeField] private bool _touch = false;
    #endregion


    #region UnityMethods    

    private void Start()
    {

    }

    private void Update()
    {
        if (!_pistolController._armed)
        {

            RaycastHit hit;

            Debug.DrawRay(transform.position, transform.forward, Color.red, _range);
            if (Physics.Raycast(transform.position, transform.forward, out hit, _range, rayLayer))
            {
                _touch = true;
                _handPos.position = hit.point;
                if (_hand == AvatarIKGoal.RightHand)
                {
                    _IKControl.rightHandObj = _handPos;
                }
                else if (_hand == AvatarIKGoal.LeftHand)
                {
                    _IKControl.leftHandObj = _handPos;
                }
                
                _IKControl.ikActive = true;
            }
            else
            {
                if (_touch)
                {
                    _handPos.position = transform.position;
                    if (_hand == AvatarIKGoal.RightHand)
                    {
                        _IKControl.rightHandObj = null;
                    }
                    else if (_hand == AvatarIKGoal.LeftHand)
                    {
                        _IKControl.leftHandObj = null;
                    }
                    _IKControl.ikActive = false;

                    _touch = false;
                }
                
            }
        }

    }

    #endregion


    #region Methods 
    #endregion
}

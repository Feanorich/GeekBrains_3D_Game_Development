﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Health : MonoBehaviour
{
    #region Fields

    [SerializeField] float HPbarHeigh = 10.0f;
    [SerializeField] float HPbarWidth = 50.0f;

    #endregion


    #region UnityMethods    

    private void OnGUI()
    {
        var HPbarPos = Camera.main.WorldToScreenPoint(transform.position);
        
        var healthPointRect = new Rect(HPbarPos.x - HPbarWidth / 2, Screen.height - HPbarPos.y - HPbarHeigh / 2,
            HPbarWidth, HPbarHeigh);

        GUI.Box(healthPointRect, "");   
        

    }

    #endregion


    #region Methods 
    #endregion
}
